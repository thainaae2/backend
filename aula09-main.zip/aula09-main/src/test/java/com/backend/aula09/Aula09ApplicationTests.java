package com.backend.aula09;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Aula09ApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.backend.aula09.controller;

import com.backend.aula09.dto.ConversaoDTO;
import com.backend.aula09.model.Conversao;
import com.backend.aula09.service.ConversaoService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/conversao")
@RequiredArgsConstructor
public class ConversaoController {

    private final ConversaoService service;
    private static final Logger logger = LoggerFactory.getLogger(ConversaoController.class);

    @PostMapping
    public Conversao converter(@RequestBody @Valid ConversaoDTO dto) {
        logger.info("Requisição para conversão de moeda");
        return service.converter(dto);
    }
}

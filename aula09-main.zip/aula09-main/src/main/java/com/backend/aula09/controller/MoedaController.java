package com.backend.aula09.controller;

import com.backend.aula09.model.Moeda;
import com.backend.aula09.service.MoedaService;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/moeda")
@RequiredArgsConstructor
public class MoedaController {

    private final MoedaService service;
    private static final Logger logger = LoggerFactory.getLogger(MoedaController.class);

    @PostMapping
    public Moeda criar(@RequestBody Moeda moeda) {
        logger.info("Requisição para criar moeda");
        return service.salvar(moeda);
    }

    @GetMapping("/codigo/{codigo}")
    public Moeda buscarPorCodigo(@PathVariable String codigo) {
        logger.info("Requisição para buscar moeda por código: {}", codigo);
        return service.buscarPorCodigo(codigo);
    }

    @PutMapping("/{id}")
    public Moeda atualizar(@PathVariable Long id, @RequestBody Moeda nova) {
        logger.info("Requisição para atualizar moeda id: {}", id);
        return service.atualizar(id, nova);
    }

    @DeleteMapping("/{id}")
    public void deletar(@PathVariable Long id) {
        logger.info("Requisição para deletar moeda id: {}", id);
        service.deletar(id);
    }
}

package com.backend.aula09.controller;

import com.backend.aula09.model.Taxa;
import com.backend.aula09.service.TaxaService;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/taxa")
@RequiredArgsConstructor
public class TaxaController {

    private final TaxaService service;
    private static final Logger logger = LoggerFactory.getLogger(TaxaController.class);

    @PostMapping
    public Taxa criar(@RequestBody Taxa taxa) {
        logger.info("Requisição para criar taxa");
        return service.salvar(taxa);
    }

    @GetMapping("/moeda/{codigo}")
    public Taxa buscarPorMoeda(@PathVariable String codigo) {
        logger.info("Requisição para buscar taxa por moeda: {}", codigo);
        return service.buscarPorMoeda(codigo);
    }

    @PutMapping("/{id}")
    public Taxa atualizar(@PathVariable Long id, @RequestBody Taxa novaTaxa) {
        logger.info("Requisição para atualizar taxa id: {}", id);
        return service.atualizar(id, novaTaxa);
    }

    @DeleteMapping("/{id}")
    public void deletar(@PathVariable Long id) {
        logger.info("Requisição para deletar taxa id: {}", id);
        service.deletar(id);
    }
}

package com.backend.aula09.repository;

import com.backend.aula09.model.Conversao;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ConversaoRepository extends JpaRepository<Conversao, Long> {
}

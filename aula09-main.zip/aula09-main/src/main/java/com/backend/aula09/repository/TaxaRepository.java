package com.backend.aula09.repository;

import com.backend.aula09.model.Moeda;
import com.backend.aula09.model.Taxa;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TaxaRepository extends JpaRepository<Taxa, Long> {
    Taxa findByMoeda(Moeda moeda);
}

package com.backend.aula09;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Aula09Application {

	public static void main(String[] args) {
		SpringApplication.run(Aula09Application.class, args);
	}

}

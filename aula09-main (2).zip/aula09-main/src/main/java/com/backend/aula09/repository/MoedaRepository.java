package com.backend.aula09.repository;

import com.backend.aula09.model.Moeda;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MoedaRepository extends JpaRepository<Moeda, Long> {
    Moeda findByCodigo(String codigo);
}
